// Test client for any of the matchmakers (Node 22+, no dependencies).
// Usage: node test.js [baseUrl] [apiKey]
//   e.g. node test.js http://localhost:8080 change-me
// It registers fake game servers, queues fake players in several regions/playlists
// and checks that everyone ends up on the right server.
const BASE = process.argv[2] || 'http://localhost:8080';
const KEY = process.argv[3] || 'change-me';
const WAIT_MS = Number(process.env.WAIT_MS || 40000);

const post = async (path, body, key) => {
  const r = await fetch(BASE + path, { method: 'POST', headers: { 'content-type': 'application/json', ...(key ? { 'x-api-key': key } : {}) }, body: JSON.stringify(body) });
  return { status: r.status, body: await r.json() };
};

let failed = 0;
const check = (ok, msg) => { console.log(`${ok ? 'PASS' : 'FAIL'}  ${msg}`); if (!ok) failed++; };

async function player(accountId, playlist, region) {
  const t = await post('/api/ticket', { accountId, playlist, region });
  if (t.status !== 200) return { accountId, error: t.body };
  const res = { accountId, states: [], play: null };
  res.done = new Promise((resolve) => {
    const ws = new WebSocket(t.body.wsUrl);
    res.ws = ws;
    ws.onmessage = (e) => {
      const m = JSON.parse(e.data);
      res.states.push(m.payload.state || m.name);
      if (m.name === 'Play') { res.play = m.payload; resolve(res); }
    };
    ws.onclose = () => resolve(res);
    ws.onerror = () => resolve(res);
  });
  return res;
}

(async () => {
  const servers = [
    { serverId: 'eu-solo-1', ip: '10.0.0.1', port: 7001, region: 'EU', playlist: 'playlist_defaultsolo' },
    { serverId: 'nae-any-1', ip: '10.0.0.2', port: 7002, region: 'NAE', playlist: 'any' },
    { serverId: 'eu-play-1', ip: '10.0.0.3', port: 7003, region: 'EU', playlist: 'playlist_playgroundv2' },
  ];
  for (const s of servers) check((await post('/api/servers/register', s, KEY)).status === 200, `register ${s.serverId}`);
  check((await post('/api/servers/register', servers[0], 'wrong-key')).status === 401, 'bad api key rejected');
  check((await post('/api/ticket', { accountId: 'x', playlist: 'nope', region: 'EU' })).status === 400, 'unknown playlist rejected');
  check((await post('/api/ticket', { accountId: 'x', playlist: 'playlist_defaultsolo', region: 'MARS' })).status === 400, 'unknown region rejected');

  const players = await Promise.all([
    player('eu1', 'playlist_defaultsolo', 'EU'), player('eu2', 'playlist_defaultsolo', 'EU'), player('eu3', 'playlist_defaultsolo', 'EU'),
    player('na1', 'playlist_defaultduo', 'NAE'), player('na2', 'playlist_defaultduo', 'NAE'),
    player('pg1', 'playlist_playgroundv2', 'EU'),
    player('as1', 'playlist_defaultsolo', 'ASIA'), player('as2', 'playlist_defaultsolo', 'ASIA'),
  ]);
  const byId = Object.fromEntries(players.map((p) => [p.accountId, p]));
  await Promise.race([Promise.all(players.filter((p) => p.done).map((p) => p.done)), new Promise((r) => setTimeout(r, WAIT_MS))]);

  const portOf = (id) => byId[id].play && byId[id].play.port;
  check(['eu1', 'eu2', 'eu3'].every((id) => portOf(id) === 7001), 'EU solo players -> eu-solo-1 (port 7001)');
  check(['na1', 'na2'].every((id) => portOf(id) === 7002), 'NAE duo players -> nae-any-1 (port 7002)');
  check(portOf('pg1') === 7003, 'EU playground player -> eu-play-1 (port 7003)');
  check(!byId.as1.play && !byId.as2.play, 'ASIA players stay queued (no ASIA server)');
  check(byId.eu1.play && byId.eu1.play.sessionId && byId.eu1.play.sessionId === byId.eu2.play.sessionId, 'same match shares one sessionId');
  const seq = byId.eu1.states.join(',');
  check(seq.startsWith('Connecting,Waiting,Queued') && seq.includes('SessionAssignment'), `client state flow: ${seq}`);

  const st = (await (await fetch(BASE + '/api/status')).json());
  check(st.queues['ASIA|playlist_defaultsolo'] === 2, `status shows 2 queued in ASIA (${JSON.stringify(st.queues)})`);

  const hb = await post('/api/servers/heartbeat', { serverId: 'eu-solo-1' }, KEY);
  check(hb.body.status === 'busy' && hb.body.session && hb.body.session.accountIds.length === 3, 'heartbeat returns session with 3 accountIds');
  await post('/api/servers/finish', { serverId: 'eu-solo-1' }, KEY);
  check((await post('/api/servers/heartbeat', { serverId: 'eu-solo-1' }, KEY)).body.status === 'idle', 'finish frees the server');

  for (const p of players) p.ws && p.ws.close();
  for (const s of servers) await post('/api/servers/unregister', { serverId: s.serverId }, KEY);
  console.log(failed ? `\n${failed} check(s) FAILED` : '\nall checks passed');
  process.exit(failed ? 1 : 0);
})();
