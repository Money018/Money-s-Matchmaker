// OGFN matchmaker (Node.js) - multiple playlists + regions
// Run: npm install && node server.js   (config: ../config.json or CONFIG env)
const http = require('http');
const fs = require('fs');
const path = require('path');
const crypto = require('crypto');
const { WebSocketServer } = require('ws');

const cfg = JSON.parse(fs.readFileSync(process.env.CONFIG || path.join(__dirname, '..', 'config.json'), 'utf8'));
const PORT = Number(process.env.PORT || cfg.port || 8080);
const API_KEY = process.env.API_KEY || cfg.apiKey;
const SERVER_TIMEOUT_MS = (cfg.serverTimeoutSec || 30) * 1000;
const TICKET_TIMEOUT_MS = 60 * 1000;

const tickets = new Map();  // ticketId -> ticket
const queues = new Map();   // "REGION|playlist" -> ticket[]
const servers = new Map();  // serverId -> game server
const log = (...a) => console.log(new Date().toISOString(), ...a);

// ---------- helpers ----------
const send = (ws, name, payload) => {
  if (ws && ws.readyState === 1) ws.send(JSON.stringify({ name, payload }));
};
const status = (ticket, payload) => send(ticket.ws, 'StatusUpdate', payload);
const json = (res, code, obj) => {
  res.writeHead(code, { 'content-type': 'application/json' });
  res.end(JSON.stringify(obj));
};
const readBody = (req) => new Promise((resolve) => {
  let data = '';
  req.on('data', (c) => { data += c; if (data.length > 1e6) req.destroy(); });
  req.on('end', () => { try { resolve(JSON.parse(data || '{}')); } catch { resolve(null); } });
});
const authed = (req) => {
  const a = Buffer.from(String(req.headers['x-api-key'] || ''));
  const b = Buffer.from(API_KEY);
  return a.length === b.length && crypto.timingSafeEqual(a, b);
};
const queueKey = (region, playlist) => `${region}|${playlist}`;
const totalQueued = () => [...queues.values()].reduce((n, q) => n + q.length, 0);
const removeFromQueue = (t) => {
  const q = queues.get(queueKey(t.region, t.playlist));
  if (!q) return;
  const i = q.indexOf(t);
  if (i >= 0) q.splice(i, 1);
};

// ---------- HTTP API ----------
const httpServer = http.createServer(async (req, res) => {
  const url = new URL(req.url, 'http://x');
  const route = `${req.method} ${url.pathname}`;

  if (route === 'GET /api/status') {
    const q = {};
    for (const [k, v] of queues) if (v.length) q[k] = v.length;
    const s = { idle: 0, busy: 0 };
    for (const sv of servers.values()) s[sv.status]++;
    return json(res, 200, { queues: q, servers: s, playlists: Object.keys(cfg.playlists), regions: cfg.regions });
  }

  // client asks for a ticket (call this from your backend's matchmaking endpoint)
  if (route === 'POST /api/ticket') {
    const body = await readBody(req);
    if (!body) return json(res, 400, { error: 'invalid json' });
    const { accountId, playlist, region } = body;
    if (!accountId) return json(res, 400, { error: 'accountId required' });
    if (!cfg.playlists[playlist]) return json(res, 400, { error: 'unknown playlist', playlists: Object.keys(cfg.playlists) });
    if (!cfg.regions.includes(region)) return json(res, 400, { error: 'unknown region', regions: cfg.regions });
    const ticketId = crypto.randomUUID().replace(/-/g, '');
    tickets.set(ticketId, { ticketId, accountId, playlist, region, ws: null, createdAt: Date.now(), queuedAt: 0 });
    const proto = req.headers['x-forwarded-proto'] === 'https' ? 'wss' : 'ws';
    return json(res, 200, { ticketId, wsUrl: `${proto}://${req.headers.host}/ws?ticket=${ticketId}` });
  }

  // ----- game server endpoints (api key required) -----
  if (url.pathname.startsWith('/api/servers/')) {
    if (!authed(req)) return json(res, 401, { error: 'bad api key' });
    const body = await readBody(req);
    if (!body) return json(res, 400, { error: 'invalid json' });

    if (route === 'POST /api/servers/register') {
      const { serverId, ip, port, region, playlist } = body;
      if (!serverId || !ip || !port) return json(res, 400, { error: 'serverId, ip, port required' });
      if (!cfg.regions.includes(region)) return json(res, 400, { error: 'unknown region' });
      if (playlist !== 'any' && !cfg.playlists[playlist]) return json(res, 400, { error: 'unknown playlist' });
      servers.set(serverId, { serverId, ip, port: Number(port), region, playlist, status: 'idle', lastSeen: Date.now(), session: null });
      log('server registered', serverId, region, playlist);
      return json(res, 200, { ok: true });
    }
    const sv = servers.get(body.serverId);
    if (!sv) return json(res, 404, { error: 'unknown server, register first' });
    if (route === 'POST /api/servers/heartbeat') {
      sv.lastSeen = Date.now();
      return json(res, 200, { status: sv.status, session: sv.session });
    }
    if (route === 'POST /api/servers/finish') {   // match over -> server is free again
      sv.status = 'idle'; sv.session = null; sv.lastSeen = Date.now();
      log('server finished', sv.serverId);
      return json(res, 200, { ok: true });
    }
    if (route === 'POST /api/servers/unregister') {
      servers.delete(sv.serverId);
      return json(res, 200, { ok: true });
    }
  }
  json(res, 404, { error: 'not found' });
});

// ---------- WebSocket (clients) ----------
const wss = new WebSocketServer({ noServer: true });
httpServer.on('upgrade', (req, socket, head) => {
  const url = new URL(req.url, 'http://x');
  const t = url.pathname === '/ws' ? tickets.get(url.searchParams.get('ticket')) : null;
  if (!t || t.ws) { socket.write('HTTP/1.1 401 Unauthorized\r\n\r\n'); return socket.destroy(); }
  wss.handleUpgrade(req, socket, head, (ws) => onConnect(ws, t));
});

function onConnect(ws, t) {
  t.ws = ws;
  status(t, { state: 'Connecting' });
  status(t, { totalPlayers: totalQueued() + 1, connectedPlayers: totalQueued() + 1, state: 'Waiting' });
  t.queuedAt = Date.now();
  const key = queueKey(t.region, t.playlist);
  if (!queues.has(key)) queues.set(key, []);
  queues.get(key).push(t);
  announce(key);
  log('queued', t.accountId, key);
  ws.on('close', () => { removeFromQueue(t); tickets.delete(t.ticketId); });
  ws.on('error', () => ws.terminate());
}

function announce(key) {
  const q = queues.get(key) || [];
  const [, playlist] = key.split('|');
  const pc = cfg.playlists[playlist];
  for (const t of q) {
    const waited = (Date.now() - q[0].queuedAt) / 1000;
    status(t, { ticketId: t.ticketId, queuedPlayers: q.length, estimatedWaitSec: Math.max(0, Math.round(pc.fillTimeoutSec - waited)), status: {}, state: 'Queued' });
  }
}

// ---------- matchmaking loop ----------
let tickCount = 0;
setInterval(() => {
  tickCount++;
  const now = Date.now();
  for (const [id, s] of servers) if (now - s.lastSeen > SERVER_TIMEOUT_MS) { servers.delete(id); log('server timed out', id); }
  for (const [id, t] of tickets) if (!t.ws && now - t.createdAt > TICKET_TIMEOUT_MS) tickets.delete(id);

  for (const [key, q] of queues) {
    if (!q.length) continue;
    const [region, playlist] = key.split('|');
    const pc = cfg.playlists[playlist];
    if (tickCount % 5 === 0) announce(key);
    const waited = (now - q[0].queuedAt) / 1000;
    const ready = q.length >= pc.maxPlayers || (q.length >= pc.minPlayers && waited >= pc.fillTimeoutSec);
    if (!ready) continue;
    const sv = [...servers.values()].find((s) => s.status === 'idle' && s.region === region && (s.playlist === playlist || s.playlist === 'any'));
    if (!sv) continue; // no free server, keep waiting

    const batch = q.splice(0, pc.maxPlayers);
    const sessionId = crypto.randomUUID().replace(/-/g, '');
    sv.status = 'busy';
    sv.session = { sessionId, playlist, region, accountIds: batch.map((t) => t.accountId) };
    log(`match ${sessionId}: ${batch.length} players -> ${sv.serverId} (${key})`);
    for (const t of batch) {
      status(t, { matchId: sessionId, state: 'SessionAssignment' });
      send(t.ws, 'Play', { matchId: sessionId, sessionId, joinDelaySec: 1, ip: sv.ip, port: sv.port });
      setTimeout(() => t.ws && t.ws.close(1000, 'match found'), 500);
    }
  }
}, 1000);

httpServer.listen(PORT, () => log(`matchmaker listening on :${PORT}`));
