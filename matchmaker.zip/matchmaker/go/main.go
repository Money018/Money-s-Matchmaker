// OGFN matchmaker (Go) - multiple playlists + regions
// Run: go mod tidy && go run .   (config: ../config.json or CONFIG env)
package main

import (
	"crypto/rand"
	"crypto/subtle"
	"encoding/hex"
	"encoding/json"
	"log"
	"net/http"
	"os"
	"path/filepath"
	"strconv"
	"strings"
	"sync"
	"time"

	"github.com/gorilla/websocket"
)

type PlaylistCfg struct {
	MinPlayers     int `json:"minPlayers"`
	MaxPlayers     int `json:"maxPlayers"`
	FillTimeoutSec int `json:"fillTimeoutSec"`
}

type Config struct {
	Port             int                    `json:"port"`
	APIKey           string                 `json:"apiKey"`
	ServerTimeoutSec int                    `json:"serverTimeoutSec"`
	Regions          []string               `json:"regions"`
	Playlists        map[string]PlaylistCfg `json:"playlists"`
}

type Ticket struct {
	ID        string
	AccountID string
	Playlist  string
	Region    string
	CreatedAt time.Time
	QueuedAt  time.Time
	conn      *websocket.Conn
	wmu       sync.Mutex
}

type Session struct {
	SessionID  string   `json:"sessionId"`
	Playlist   string   `json:"playlist"`
	Region     string   `json:"region"`
	AccountIDs []string `json:"accountIds"`
}

type GameServer struct {
	ID       string
	IP       string
	Port     int
	Region   string
	Playlist string
	Status   string // idle | busy
	LastSeen time.Time
	Session  *Session
}

var (
	cfg     Config
	mu      sync.Mutex
	tickets = map[string]*Ticket{}
	queues  = map[string][]*Ticket{}
	servers = map[string]*GameServer{}
)

func newID() string {
	b := make([]byte, 16)
	rand.Read(b)
	return hex.EncodeToString(b)
}

func queueKey(region, playlist string) string { return region + "|" + playlist }

func send(t *Ticket, name string, payload map[string]any) {
	t.wmu.Lock()
	defer t.wmu.Unlock()
	if t.conn != nil {
		t.conn.WriteJSON(map[string]any{"name": name, "payload": payload})
	}
}

func status(t *Ticket, payload map[string]any) { send(t, "StatusUpdate", payload) }

func writeJSON(w http.ResponseWriter, code int, v any) {
	w.Header().Set("content-type", "application/json")
	w.WriteHeader(code)
	json.NewEncoder(w).Encode(v)
}

func readBody(r *http.Request) (map[string]any, bool) {
	var m map[string]any
	if err := json.NewDecoder(http.MaxBytesReader(nil, r.Body, 1<<20)).Decode(&m); err != nil {
		return nil, false
	}
	return m, true
}

func str(m map[string]any, k string) string { s, _ := m[k].(string); return s }

func authed(r *http.Request) bool {
	return subtle.ConstantTimeCompare([]byte(r.Header.Get("x-api-key")), []byte(cfg.APIKey)) == 1
}

func contains(list []string, s string) bool {
	for _, x := range list {
		if x == s {
			return true
		}
	}
	return false
}

func removeFromQueue(t *Ticket) {
	key := queueKey(t.Region, t.Playlist)
	q := queues[key]
	for i, x := range q {
		if x == t {
			queues[key] = append(q[:i], q[i+1:]...)
			return
		}
	}
}

func announce(key string) {
	q := queues[key]
	if len(q) == 0 {
		return
	}
	pc := cfg.Playlists[strings.SplitN(key, "|", 2)[1]]
	waited := time.Since(q[0].QueuedAt).Seconds()
	est := pc.FillTimeoutSec - int(waited)
	if est < 0 {
		est = 0
	}
	for _, t := range q {
		status(t, map[string]any{"ticketId": t.ID, "queuedPlayers": len(q), "estimatedWaitSec": est, "status": map[string]any{}, "state": "Queued"})
	}
}

// ---------- HTTP ----------
func handleStatus(w http.ResponseWriter, r *http.Request) {
	mu.Lock()
	defer mu.Unlock()
	q := map[string]int{}
	for k, v := range queues {
		if len(v) > 0 {
			q[k] = len(v)
		}
	}
	s := map[string]int{"idle": 0, "busy": 0}
	for _, sv := range servers {
		s[sv.Status]++
	}
	pl := []string{}
	for k := range cfg.Playlists {
		pl = append(pl, k)
	}
	writeJSON(w, 200, map[string]any{"queues": q, "servers": s, "playlists": pl, "regions": cfg.Regions})
}

func handleTicket(w http.ResponseWriter, r *http.Request) {
	body, ok := readBody(r)
	if !ok {
		writeJSON(w, 400, map[string]any{"error": "invalid json"})
		return
	}
	acc, playlist, region := str(body, "accountId"), str(body, "playlist"), str(body, "region")
	if acc == "" {
		writeJSON(w, 400, map[string]any{"error": "accountId required"})
		return
	}
	if _, ok := cfg.Playlists[playlist]; !ok {
		writeJSON(w, 400, map[string]any{"error": "unknown playlist"})
		return
	}
	if !contains(cfg.Regions, region) {
		writeJSON(w, 400, map[string]any{"error": "unknown region", "regions": cfg.Regions})
		return
	}
	t := &Ticket{ID: newID(), AccountID: acc, Playlist: playlist, Region: region, CreatedAt: time.Now()}
	mu.Lock()
	tickets[t.ID] = t
	mu.Unlock()
	proto := "ws"
	if r.Header.Get("x-forwarded-proto") == "https" {
		proto = "wss"
	}
	writeJSON(w, 200, map[string]any{"ticketId": t.ID, "wsUrl": proto + "://" + r.Host + "/ws?ticket=" + t.ID})
}

func handleServers(w http.ResponseWriter, r *http.Request) {
	if !authed(r) {
		writeJSON(w, 401, map[string]any{"error": "bad api key"})
		return
	}
	body, ok := readBody(r)
	if !ok {
		writeJSON(w, 400, map[string]any{"error": "invalid json"})
		return
	}
	action := strings.TrimPrefix(r.URL.Path, "/api/servers/")
	mu.Lock()
	defer mu.Unlock()

	if action == "register" {
		id, ip := str(body, "serverId"), str(body, "ip")
		portF, _ := body["port"].(float64)
		region, playlist := str(body, "region"), str(body, "playlist")
		if id == "" || ip == "" || portF == 0 {
			writeJSON(w, 400, map[string]any{"error": "serverId, ip, port required"})
			return
		}
		if !contains(cfg.Regions, region) {
			writeJSON(w, 400, map[string]any{"error": "unknown region"})
			return
		}
		if _, ok := cfg.Playlists[playlist]; !ok && playlist != "any" {
			writeJSON(w, 400, map[string]any{"error": "unknown playlist"})
			return
		}
		servers[id] = &GameServer{ID: id, IP: ip, Port: int(portF), Region: region, Playlist: playlist, Status: "idle", LastSeen: time.Now()}
		log.Println("server registered", id, region, playlist)
		writeJSON(w, 200, map[string]any{"ok": true})
		return
	}
	sv := servers[str(body, "serverId")]
	if sv == nil {
		writeJSON(w, 404, map[string]any{"error": "unknown server, register first"})
		return
	}
	switch action {
	case "heartbeat":
		sv.LastSeen = time.Now()
		writeJSON(w, 200, map[string]any{"status": sv.Status, "session": sv.Session})
	case "finish":
		sv.Status, sv.Session, sv.LastSeen = "idle", nil, time.Now()
		log.Println("server finished", sv.ID)
		writeJSON(w, 200, map[string]any{"ok": true})
	case "unregister":
		delete(servers, sv.ID)
		writeJSON(w, 200, map[string]any{"ok": true})
	default:
		writeJSON(w, 404, map[string]any{"error": "not found"})
	}
}

// ---------- WebSocket ----------
var upgrader = websocket.Upgrader{CheckOrigin: func(*http.Request) bool { return true }}

func handleWS(w http.ResponseWriter, r *http.Request) {
	id := r.URL.Query().Get("ticket")
	mu.Lock()
	t := tickets[id]
	if t == nil || t.conn != nil {
		mu.Unlock()
		http.Error(w, "unauthorized", 401)
		return
	}
	mu.Unlock()
	conn, err := upgrader.Upgrade(w, r, nil)
	if err != nil {
		return
	}

	mu.Lock()
	t.conn = conn
	total := 1
	for _, q := range queues {
		total += len(q)
	}
	status(t, map[string]any{"state": "Connecting"})
	status(t, map[string]any{"totalPlayers": total, "connectedPlayers": total, "state": "Waiting"})
	t.QueuedAt = time.Now()
	key := queueKey(t.Region, t.Playlist)
	queues[key] = append(queues[key], t)
	announce(key)
	log.Println("queued", t.AccountID, key)
	mu.Unlock()

	for { // read loop: just detect disconnects
		if _, _, err := conn.ReadMessage(); err != nil {
			break
		}
	}
	mu.Lock()
	removeFromQueue(t)
	delete(tickets, t.ID)
	mu.Unlock()
	conn.Close()
}

// ---------- matchmaking loop ----------
func tick(n int) {
	mu.Lock()
	defer mu.Unlock()
	now := time.Now()
	for id, s := range servers {
		if now.Sub(s.LastSeen) > time.Duration(cfg.ServerTimeoutSec)*time.Second {
			delete(servers, id)
			log.Println("server timed out", id)
		}
	}
	for id, t := range tickets {
		if t.conn == nil && now.Sub(t.CreatedAt) > 60*time.Second {
			delete(tickets, id)
		}
	}
	for key, q := range queues {
		if len(q) == 0 {
			continue
		}
		parts := strings.SplitN(key, "|", 2)
		region, playlist := parts[0], parts[1]
		pc := cfg.Playlists[playlist]
		if n%5 == 0 {
			announce(key)
		}
		waited := now.Sub(q[0].QueuedAt)
		ready := len(q) >= pc.MaxPlayers || (len(q) >= pc.MinPlayers && waited >= time.Duration(pc.FillTimeoutSec)*time.Second)
		if !ready {
			continue
		}
		var sv *GameServer
		for _, s := range servers {
			if s.Status == "idle" && s.Region == region && (s.Playlist == playlist || s.Playlist == "any") {
				sv = s
				break
			}
		}
		if sv == nil {
			continue // no free server, keep waiting
		}
		cnt := len(q)
		if cnt > pc.MaxPlayers {
			cnt = pc.MaxPlayers
		}
		batch := append([]*Ticket{}, q[:cnt]...)
		queues[key] = q[cnt:]
		sid := newID()
		ids := make([]string, len(batch))
		for i, t := range batch {
			ids[i] = t.AccountID
		}
		sv.Status = "busy"
		sv.Session = &Session{SessionID: sid, Playlist: playlist, Region: region, AccountIDs: ids}
		log.Printf("match %s: %d players -> %s (%s)", sid, len(batch), sv.ID, key)
		for _, t := range batch {
			status(t, map[string]any{"matchId": sid, "state": "SessionAssignment"})
			send(t, "Play", map[string]any{"matchId": sid, "sessionId": sid, "joinDelaySec": 1, "ip": sv.IP, "port": sv.Port})
			go func(t *Ticket) {
				time.Sleep(500 * time.Millisecond)
				t.wmu.Lock()
				t.conn.WriteControl(websocket.CloseMessage, websocket.FormatCloseMessage(1000, "match found"), time.Now().Add(time.Second))
				t.wmu.Unlock()
			}(t)
		}
	}
}

func main() {
	path := os.Getenv("CONFIG")
	if path == "" {
		path = filepath.Join("..", "config.json")
	}
	raw, err := os.ReadFile(path)
	if err != nil {
		log.Fatal(err)
	}
	if err := json.Unmarshal(raw, &cfg); err != nil {
		log.Fatal(err)
	}
	if v := os.Getenv("PORT"); v != "" {
		cfg.Port, _ = strconv.Atoi(v)
	}
	if v := os.Getenv("API_KEY"); v != "" {
		cfg.APIKey = v
	}
	if cfg.ServerTimeoutSec == 0 {
		cfg.ServerTimeoutSec = 30
	}

	go func() {
		n := 0
		for range time.Tick(time.Second) {
			n++
			tick(n)
		}
	}()

	mux := http.NewServeMux()
	mux.HandleFunc("GET /api/status", handleStatus)
	mux.HandleFunc("POST /api/ticket", handleTicket)
	mux.HandleFunc("POST /api/servers/", handleServers)
	mux.HandleFunc("GET /ws", handleWS)
	log.Printf("matchmaker listening on :%d", cfg.Port)
	log.Fatal(http.ListenAndServe(":"+strconv.Itoa(cfg.Port), mux))
}
