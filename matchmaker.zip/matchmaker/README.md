# OGFN Matchmaker

One protocol, three server implementations (Node, Go, C#) and a JS test client.
All read the same `config.json`, so you can switch languages without changing anything else.

```
matchmaker/
  config.json     regions, playlists (modes), api key, port
  node/           Node.js (needs: npm install)
  go/             Go 1.22+ (needs: go mod tidy)
  csharp/         .NET 8
  tools/test.js   JS test client (Node 22+, no dependencies)
```

## Run

| Language | Command (from inside its folder) |
|----------|----------------------------------|
| Node     | `npm install && node server.js`  |
| Go       | `go mod tidy && go run .`        |
| C#       | `dotnet run`                     |

Env overrides: `PORT`, `API_KEY`, `CONFIG` (path to config file).
**Change `apiKey` in `config.json` before exposing this to the internet.**

## Test

With a matchmaker running:

```
node tools/test.js http://localhost:8080 change-me
```

It registers 3 fake game servers, queues 8 fake players across regions and modes,
and checks that every group lands on the right server. For a quick run, lower
`fillTimeoutSec` in the config (default is 30 s for the big modes).

## How it works

1. Your backend's matchmaking endpoint calls `POST /api/ticket` with `{accountId, playlist, region}` and gets back `{ticketId, wsUrl}`. The client connects to `wsUrl`.
2. The client receives `StatusUpdate` messages: `Connecting`, `Waiting`, `Queued` (repeats every ~5 s with queue size and estimated wait), `SessionAssignment`, then a `Play` message with `matchId`, `sessionId`, `ip` and `port`, and the socket closes.
3. Every (region, playlist) pair has its own queue. A match starts when the queue holds `maxPlayers`, or at least `minPlayers` after the oldest player has waited `fillTimeoutSec`, **and** an idle game server exists for that region and playlist. If none is free, players keep waiting.

## Game server API (header `x-api-key` required, JSON bodies)

| Endpoint | Body | Purpose |
|----------|------|---------|
| `POST /api/servers/register` | `serverId, ip, port, region, playlist` | Announce a free server. `playlist` can be `"any"`. |
| `POST /api/servers/heartbeat` | `serverId` | Call every ~10 s. Response: `{status, session}`. When `session` is set, that is the match to host (`sessionId`, `accountIds`). Servers silent for `serverTimeoutSec` are dropped. |
| `POST /api/servers/finish` | `serverId` | Match over, server is idle again. |
| `POST /api/servers/unregister` | `serverId` | Remove the server. |

`GET /api/status` (no key) shows queue sizes and server counts per state.

## Adding modes and regions

Edit `config.json`: add a key under `playlists` (the id your client sends, e.g. `playlist_defaultsolo`) or an entry in `regions`. Restart the matchmaker.

## Things to know

- The message names and fields follow the usual Fortnite-style flow (`StatusUpdate` / `Play`), but I could not check them against your exact client build. If your client expects different fields, change the `status(...)` / `send(...)` calls (Node), `status`/`send` (Go) or `Send(...)` (C#). Everything else stays the same.
- Teams are not handled yet: a duo or squad is queued as individual players. Party support means grouping by a `partyId` in the ticket.
- State is in memory. Restarting the matchmaker empties the queues, and game servers must register again (have them re-register when a heartbeat returns 404).
- Run it behind HTTPS (nginx, Caddy or Cloudflare) if clients connect from outside; the matchmaker honors `x-forwarded-proto` and hands out `wss://` URLs.
