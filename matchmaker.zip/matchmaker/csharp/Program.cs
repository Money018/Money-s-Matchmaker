// OGFN matchmaker (C# / .NET 8) - multiple playlists + regions
// Run: dotnet run   (config: ../config.json or CONFIG env)
using System.Net.WebSockets;
using System.Security.Cryptography;
using System.Text;
using System.Text.Json;
using System.Text.Json.Nodes;

var cfgPath = Environment.GetEnvironmentVariable("CONFIG") ?? Path.Combine(Directory.GetCurrentDirectory(), "..", "config.json");
var cfg = JsonNode.Parse(File.ReadAllText(cfgPath))!;
var port = int.Parse(Environment.GetEnvironmentVariable("PORT") ?? cfg["port"]!.ToString());
var apiKey = Environment.GetEnvironmentVariable("API_KEY") ?? cfg["apiKey"]!.GetValue<string>();
var serverTimeoutSec = cfg["serverTimeoutSec"]?.GetValue<int>() ?? 30;
var regions = cfg["regions"]!.AsArray().Select(x => x!.GetValue<string>()).ToHashSet();
var playlists = cfg["playlists"]!.AsObject().ToDictionary(
    kv => kv.Key,
    kv => new PlaylistCfg(kv.Value!["minPlayers"]!.GetValue<int>(), kv.Value!["maxPlayers"]!.GetValue<int>(), kv.Value!["fillTimeoutSec"]!.GetValue<int>()));

var gate = new object();
var tickets = new Dictionary<string, Ticket>();
var queues = new Dictionary<string, List<Ticket>>();
var servers = new Dictionary<string, GameServer>();

string NewId() => Convert.ToHexString(RandomNumberGenerator.GetBytes(16)).ToLowerInvariant();
string Key(string region, string playlist) => region + "|" + playlist;
bool Authed(HttpRequest r) =>
    CryptographicOperations.FixedTimeEquals(Encoding.UTF8.GetBytes(r.Headers["x-api-key"].ToString()), Encoding.UTF8.GetBytes(apiKey));

async Task Send(Ticket t, string name, object payload)
{
    var sock = t.Socket;
    if (sock is not { State: WebSocketState.Open }) return;
    var bytes = JsonSerializer.SerializeToUtf8Bytes(new { name, payload });
    await t.WriteLock.WaitAsync();
    try { await sock.SendAsync(bytes, WebSocketMessageType.Text, true, CancellationToken.None); }
    catch { }
    finally { t.WriteLock.Release(); }
}

object QueuedMsg(Ticket t, int count, double waited, PlaylistCfg pc) =>
    new { ticketId = t.Id, queuedPlayers = count, estimatedWaitSec = Math.Max(0, (int)(pc.FillSec - waited)), status = new { }, state = "Queued" };

var builder = WebApplication.CreateBuilder(args);
builder.WebHost.UseUrls($"http://0.0.0.0:{port}");
var app = builder.Build();
app.UseWebSockets();

// ---------- HTTP API ----------
app.MapGet("/api/status", () =>
{
    lock (gate)
    {
        var q = queues.Where(k => k.Value.Count > 0).ToDictionary(k => k.Key, k => k.Value.Count);
        return Results.Json(new
        {
            queues = q,
            servers = new { idle = servers.Values.Count(s => s.Status == "idle"), busy = servers.Values.Count(s => s.Status == "busy") },
            playlists = playlists.Keys,
            regions
        });
    }
});

app.MapPost("/api/ticket", (HttpRequest req, JsonObject body) =>
{
    var accountId = body["accountId"]?.GetValue<string>();
    var playlist = body["playlist"]?.GetValue<string>() ?? "";
    var region = body["region"]?.GetValue<string>() ?? "";
    if (string.IsNullOrEmpty(accountId)) return Results.BadRequest(new { error = "accountId required" });
    if (!playlists.ContainsKey(playlist)) return Results.BadRequest(new { error = "unknown playlist", playlists = playlists.Keys });
    if (!regions.Contains(region)) return Results.BadRequest(new { error = "unknown region", regions });
    var t = new Ticket { Id = NewId(), AccountId = accountId, Playlist = playlist, Region = region, CreatedAt = DateTime.UtcNow };
    lock (gate) tickets[t.Id] = t;
    var proto = req.Headers["x-forwarded-proto"] == "https" ? "wss" : "ws";
    return Results.Json(new { ticketId = t.Id, wsUrl = $"{proto}://{req.Host}/ws?ticket={t.Id}" });
});

// ----- game server endpoints (api key required) -----
app.MapPost("/api/servers/{action}", (HttpRequest req, string action, JsonObject body) =>
{
    if (!Authed(req)) return Results.Json(new { error = "bad api key" }, statusCode: 401);
    lock (gate)
    {
        if (action == "register")
        {
            var id = body["serverId"]?.GetValue<string>();
            var ip = body["ip"]?.GetValue<string>();
            var p = body["port"]?.GetValue<int>() ?? 0;
            var region = body["region"]?.GetValue<string>() ?? "";
            var playlist = body["playlist"]?.GetValue<string>() ?? "";
            if (string.IsNullOrEmpty(id) || string.IsNullOrEmpty(ip) || p == 0) return Results.BadRequest(new { error = "serverId, ip, port required" });
            if (!regions.Contains(region)) return Results.BadRequest(new { error = "unknown region" });
            if (playlist != "any" && !playlists.ContainsKey(playlist)) return Results.BadRequest(new { error = "unknown playlist" });
            servers[id] = new GameServer { Id = id, Ip = ip, Port = p, Region = region, Playlist = playlist, Status = "idle", LastSeen = DateTime.UtcNow };
            Console.WriteLine($"server registered {id} {region} {playlist}");
            return Results.Json(new { ok = true });
        }
        var sid = body["serverId"]?.GetValue<string>() ?? "";
        if (!servers.TryGetValue(sid, out var sv)) return Results.NotFound(new { error = "unknown server, register first" });
        switch (action)
        {
            case "heartbeat":
                sv.LastSeen = DateTime.UtcNow;
                return Results.Json(new { status = sv.Status, session = sv.Session });
            case "finish":
                sv.Status = "idle"; sv.Session = null; sv.LastSeen = DateTime.UtcNow;
                Console.WriteLine($"server finished {sv.Id}");
                return Results.Json(new { ok = true });
            case "unregister":
                servers.Remove(sv.Id);
                return Results.Json(new { ok = true });
            default:
                return Results.NotFound(new { error = "not found" });
        }
    }
});

// ---------- WebSocket (clients) ----------
app.Map("/ws", async (HttpContext ctx) =>
{
    if (!ctx.WebSockets.IsWebSocketRequest) { ctx.Response.StatusCode = 400; return; }
    Ticket? t;
    lock (gate)
    {
        tickets.TryGetValue(ctx.Request.Query["ticket"].ToString(), out t);
        if (t != null && t.Socket != null) t = null;
    }
    if (t == null) { ctx.Response.StatusCode = 401; return; }

    var sock = await ctx.WebSockets.AcceptWebSocketAsync();
    int total;
    string key;
    lock (gate)
    {
        t.Socket = sock;
        total = queues.Values.Sum(q => q.Count) + 1;
        t.QueuedAt = DateTime.UtcNow;
        key = Key(t.Region, t.Playlist);
        if (!queues.ContainsKey(key)) queues[key] = new();
        queues[key].Add(t);
    }
    await Send(t, "StatusUpdate", new { state = "Connecting" });
    await Send(t, "StatusUpdate", new { totalPlayers = total, connectedPlayers = total, state = "Waiting" });
    int count; var pc = playlists[t.Playlist];
    lock (gate) count = queues[key].Count;
    await Send(t, "StatusUpdate", QueuedMsg(t, count, 0, pc));
    Console.WriteLine($"queued {t.AccountId} {key}");

    var buf = new byte[1024];
    try
    {
        while (sock.State == WebSocketState.Open)
        {
            var r = await sock.ReceiveAsync(buf, ctx.RequestAborted);
            if (r.MessageType == WebSocketMessageType.Close) break;
        }
    }
    catch { }
    lock (gate)
    {
        if (queues.TryGetValue(key, out var q)) q.Remove(t);
        tickets.Remove(t.Id);
    }
});

// ---------- matchmaking loop ----------
_ = Task.Run(async () =>
{
    var timer = new PeriodicTimer(TimeSpan.FromSeconds(1));
    var n = 0;
    while (await timer.WaitForNextTickAsync())
    {
        n++;
        try { await Tick(n % 5 == 0); } catch (Exception e) { Console.WriteLine(e); }
    }
});

async Task Tick(bool announce)
{
    var outbox = new List<(Ticket t, string name, object payload)>();
    var toClose = new List<Ticket>();
    lock (gate)
    {
        var now = DateTime.UtcNow;
        foreach (var id in servers.Where(s => (now - s.Value.LastSeen).TotalSeconds > serverTimeoutSec).Select(s => s.Key).ToList())
        { servers.Remove(id); Console.WriteLine($"server timed out {id}"); }
        foreach (var id in tickets.Where(x => x.Value.Socket == null && (now - x.Value.CreatedAt).TotalSeconds > 60).Select(x => x.Key).ToList())
            tickets.Remove(id);

        foreach (var (key, q) in queues)
        {
            if (q.Count == 0) continue;
            var parts = key.Split('|');
            var region = parts[0]; var playlist = parts[1];
            var pc = playlists[playlist];
            var waited = (now - q[0].QueuedAt).TotalSeconds;
            if (announce) foreach (var t in q) outbox.Add((t, "StatusUpdate", QueuedMsg(t, q.Count, waited, pc)));
            var ready = q.Count >= pc.Max || (q.Count >= pc.Min && waited >= pc.FillSec);
            if (!ready) continue;
            var sv = servers.Values.FirstOrDefault(s => s.Status == "idle" && s.Region == region && (s.Playlist == playlist || s.Playlist == "any"));
            if (sv == null) continue; // no free server, keep waiting

            var batch = q.Take(pc.Max).ToList();
            q.RemoveRange(0, batch.Count);
            var sessionId = NewId();
            sv.Status = "busy";
            sv.Session = new Session(sessionId, playlist, region, batch.Select(b => b.AccountId).ToList());
            Console.WriteLine($"match {sessionId}: {batch.Count} players -> {sv.Id} ({key})");
            foreach (var t in batch)
            {
                outbox.Add((t, "StatusUpdate", new { matchId = sessionId, state = "SessionAssignment" }));
                outbox.Add((t, "Play", new { matchId = sessionId, sessionId, joinDelaySec = 1, ip = sv.Ip, port = sv.Port }));
                toClose.Add(t);
            }
        }
    }
    foreach (var (t, name, payload) in outbox) await Send(t, name, payload);
    foreach (var t in toClose)
    {
        try { if (t.Socket is { State: WebSocketState.Open } s) await s.CloseAsync(WebSocketCloseStatus.NormalClosure, "match found", CancellationToken.None); }
        catch { }
    }
}

Console.WriteLine($"matchmaker listening on :{port}");
app.Run();

record PlaylistCfg(int Min, int Max, int FillSec);
record Session(string SessionId, string Playlist, string Region, List<string> AccountIds);

class Ticket
{
    public string Id = "", AccountId = "", Playlist = "", Region = "";
    public DateTime CreatedAt, QueuedAt;
    public WebSocket? Socket;
    public SemaphoreSlim WriteLock = new(1, 1);
}

class GameServer
{
    public string Id = "", Ip = "", Region = "", Playlist = "", Status = "idle";
    public int Port;
    public DateTime LastSeen;
    public Session? Session;
}
